package com.example.eventsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
