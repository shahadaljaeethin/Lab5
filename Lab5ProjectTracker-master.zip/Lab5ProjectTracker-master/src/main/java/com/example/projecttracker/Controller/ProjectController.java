package com.example.projecttracker.Controller;

import com.example.projecttracker.Api.ApiResposne;
import com.example.projecttracker.Model.Project;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/project tracker")
public class ProjectController {
ArrayList<Project> projects = new ArrayList<>();
//--
@PostMapping("/add")
public ApiResposne createProject(@RequestBody Project p){
projects.add(p);
return new ApiResposne("project "+p.getTitle()+" for company "+p.getCompanyName()+" is added.");
}
@GetMapping("/get/all")
public ArrayList<Project> displayAll(){
return projects;
}
@PutMapping("update/{ID}")
public ApiResposne updateProject(@PathVariable String ID,@RequestBody Project p){
int index=0;
for(Project prj:projects) if(prj.getID().equals(ID)) break; else index++;
projects.set(index,p);
return new ApiResposne("project "+projects.get(index).getTitle()+" updated");
}
@DeleteMapping("/delete/{ID}")
public ApiResposne deleteProject(@PathVariable String ID){
    int index=0;
    for(Project prj:projects) if(prj.getID().equals(ID)) break; else index++;
    String oldName=projects.get(index).getTitle();
    projects.remove(index);
    return new ApiResposne("The project "+oldName+" is deleted.");
}
@PutMapping("/status/{ID}")
    public ApiResposne setDone(@PathVariable String ID){
    int index=0;
    for(Project p:projects) if(p.getID().equals(ID)) break; else index++;
    if(!projects.get(index).isStatus())
    projects.get(index).setStatus(true);
    else
    return new ApiResposne("The Project is already done.");
    return new ApiResposne("The Project set to finished :)!");
    }
@GetMapping("/get/title/{title}")
public Project search(@PathVariable String title){
for(Project p:projects)
if(p.getTitle().equalsIgnoreCase(title)) return p;
return null;
}

@GetMapping("/get/{companyName}")
public ArrayList<Project> displayCompany(@PathVariable String companyName)
{
ArrayList<Project> company = new ArrayList<>();
for(Project p:projects) {
    if (p.getCompanyName().equalsIgnoreCase(companyName))
        company.add(p);
}
return company;
}
}
