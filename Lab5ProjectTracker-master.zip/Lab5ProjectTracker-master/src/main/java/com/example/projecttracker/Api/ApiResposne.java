package com.example.projecttracker.Api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiResposne {
private String message;
}
