package com.example.student.Controller;

import com.example.student.Api.ApiResponse;
import com.example.student.Model.Student;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/student")
public class StudentController {
//--Database:
ArrayList<Student> allStudents = new ArrayList<>();
//--
@PostMapping("/add")
public ApiResponse createStudent(@RequestBody Student s){
allStudents.add(s);
return new ApiResponse("The student "+s.getName()+" is added.");
}
@GetMapping("/get/all")
public ArrayList<Student> getAllStudents(){
return allStudents;
}
@GetMapping("/get/special")
public ArrayList<Student> getSpecialStudents(){
    double sum=0;
    for (Student s:allStudents)
    {
        sum+=s.getGPA();
    }
    double average = sum/allStudents.size();
    System.out.println("avrg is "+average);
if(average==-1) return allStudents;
ArrayList<Student> specialStudents = new ArrayList<>();
for (Student s:allStudents)
{
if(s.getGPA()>average) specialStudents.add(s);
}
return specialStudents;
}
//@Bean
//@Qualifier("Average")
//public double averageGPA(){
//if(allStudents.isEmpty()) return -1;
//double sum=0;
//for (Student s:allStudents)
//{
//sum+=s.getGPA();
//}
//return sum/allStudents.size();
//}
@PutMapping("/update/{index}")
public ApiResponse updateStudent(@PathVariable int index,@RequestBody Student s){
allStudents.set(index,s);
return new ApiResponse("student "+s.getName()+" is updated.");
}
@DeleteMapping("/delete/{index}")
public ApiResponse deleteStudent(@PathVariable int index)
{
String oldName = allStudents.get(index).getName();
allStudents.remove(index);
return new ApiResponse("the student "+oldName+" is deleted");
}
@GetMapping("/get/honor/{index}")
public ApiResponse isHonor(@PathVariable int index){
//honor degree A if 4.75 to 5
//honor degree B if 4.25 to 4.76
String name = allStudents.get(index).getName();
double A= 4.75,B=4.25,studentGPA=allStudents.get(index).getGPA();
String honorMessage="";

if(studentGPA>=A) honorMessage="The student "+name+" has the honor (1)!";
else if(studentGPA>=B) honorMessage="The student "+name+" has the honor (2)!";
else honorMessage="The student "+name+" has normal degree";
return new ApiResponse(honorMessage);

}

}
